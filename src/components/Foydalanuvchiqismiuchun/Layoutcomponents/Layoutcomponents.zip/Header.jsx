import Navbar from "./Navbar";
import FilialHeaderMenu from "./Menu/Filial/Filialheadermenu";
import { PiSignIn } from "react-icons/pi";
import { useRejimlarContext } from "/src/context/Rejimlar";
import Yangiliklarheadermenu from "./Menu/Yangiliklar/Yangiliklarheadermenu";
import Tuzilmaheader from "./Menu/Tuzilma/Tuzilmaheader";
import Faoliyatheadermenu from "./Menu/Faoliyat/Faoliyatheadermenu";
import Qabulheadermenu from "./Menu/Qabul/Qabulheadermenu";
import Talabalargaheadermenu from "./Menu/Talabalarga/Talabalargaheadermenu";


const Header = () => {
  const {
    toggleDarkMode,
    toggleAccessibility,
    toggleDaltonicMode,
    changeLanguage,
  } = useRejimlarContext();

  return (
    <div className="bg-gray-100 dark:bg-gray-800">
      <Navbar
        toggleDarkMode={toggleDarkMode}
        toggleAccessibility={toggleAccessibility}
        toggleDaltonicMode={toggleDaltonicMode}
        changeLanguage={changeLanguage}
      />
      <header className="container mx-auto px-4 py-6 flex items-center justify-between">
        <img src="/logo.png" alt="Logo" className="w-12 h-12" />
        <a
          href="/"
          className="text-xl font-bold text-black dark:text-white"
          aria-label="Samarqand davlat universiteti Kattaqo‘rg‘on filiali"
        >
          Samarqand davlat universiteti Kattaqo‘rg‘on filiali
        </a>

        <nav className="flex items-center justify-center font-semibold">
          <FilialHeaderMenu />
          <Yangiliklarheadermenu />
          <Tuzilmaheader />
          <Faoliyatheadermenu />
          <Qabulheadermenu />
          <Talabalargaheadermenu />
        </nav>

        <nav>
          <ul className="flex items-center space-x-4 ">
            <li>
              <a
                href="/"
                className="rounded-full px-3 py-2 text-xs font-semibold bg-black text-gray-800 bg-opacity-10 flex items-center group "
                aria-label="Kirish"
              >
                <span className="mr-2 dark:text-white ">Kirish</span>
                <PiSignIn className="text-base dark:text-white" />
              </a>
            </li>
          </ul>
        </nav>
      </header>
    </div>
  );
};

export default Header;
